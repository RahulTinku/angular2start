import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

const API_PREFIX = "http://localhost:3001/api";

@Injectable({
  providedIn: "root",
})
export class CommentService {
  constructor(private http: HttpClient) {}

  /**
   * Reset comments back to original state.
   */
  resetComments(): Observable<any> {
    return this.http.post(`${API_PREFIX}/reset-comments`, {});
  }
  getAllComment(): Observable<any> {
    return this.http.get(`${API_PREFIX}/comments`);
  }
  getComment(id: string): Observable<any> {
    return this.http.get(`${API_PREFIX}/comments/${id}`);
  }
  addComment(body: any): Observable<any> {
    return this.http.post(`${API_PREFIX}/comments`, body);
  }
  deleteComment(id: string): Observable<any> {
    return this.http.delete(`${API_PREFIX}/comments/${id}`);
  }
  searchComment(query: String): Observable<any> {
    return this.http.get(`${API_PREFIX}/comments?q=${query}`);
  }
}
