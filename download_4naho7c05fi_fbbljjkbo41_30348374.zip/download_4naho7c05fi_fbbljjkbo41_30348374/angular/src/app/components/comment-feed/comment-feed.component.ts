import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";

import { CommentService } from "./../../services/comment.service";

@Component({
  selector: "app-comment-feed",
  templateUrl: "./comment-feed.component.html",
  styleUrls: ["./comment-feed.component.css"],
})
export class CommentFeedComponent implements OnInit {
  comments: Comment[];
  errorMessage = "";
  commentList: any;
  formGroup: FormGroup;

  constructor(
    private commentService: CommentService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.commentService.getAllComment().subscribe((res) => {
      this.commentList = res;
    });
    this.formGroup = this.formBuilder.group({
      commentBox: [this.commentList],
      search: [],
    });
  }

  resetCommentFeed() {
    this.commentService.resetComments().subscribe();
  }
  addComment() {
    let comment = { text: this.formGroup.get("commentBox").value };
    this.commentService.addComment(comment).subscribe((res) => {
      this.commentList.push(res);
    });
  }
  delteComment(item) {
    this.commentService.deleteComment(item.id).subscribe((res) => {
      this.commentList = this.commentList.filter((data) => data.id !== item.id);
    });
  }
  searchComment() {
    let query = this.formGroup.get("search").value;
    console.log(query);
  }
}
